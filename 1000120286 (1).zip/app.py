import requests

def check_url(url):
    try:
        response = requests.get(url, timeout=5)
        return response.status_code
    except requests.exceptions.RequestException:
        return "Error"

def main():
    print("🔗 URL Status Checker")
    url = input("Enter URL: ")

    if not url.startswith("http"):
        url = "https://" + url

    status = check_url(url)

    if status == "Error":
        print("❌ Unable to reach the URL")
    else:
        print(f"✅ Status Code: {status}")

if __name__ == "__main__":
    main()
