# URL Status Checker

A simple Python project to check whether a website is reachable and display its HTTP status code.

## 🚀 Features
- Checks website status
- Handles invalid URLs
- Simple CLI interface

## ▶️ Run the Project
pip install -r requirements.txt
python app.py

## 📌 Example Output
Enter URL: google.com
Status Code: 200
